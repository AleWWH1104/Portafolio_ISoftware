const request = require('supertest');
const app = require('../src/app');
const pool = require('../src/config/testdb');
const bcrypt = require('bcrypt');

describe('AUTH1 - Flujo Completo de Autenticación', () => {
  // Datos de prueba
  const testUser = {
    Fullname: "Usuario de Prueba",
    email: "auth_test@validation.com",
    password: "password123"
  };

  let authCookie;

  // Limpieza antes y después de las pruebas
  beforeAll(async () => {
    // Eliminar usuario de prueba si existe
    await pool.query('DELETE FROM usuarios WHERE email = $1', [testUser.email]);
  });

  afterAll(async () => {
    // Cerrar conexión a la base de datos
    await pool.end();
  });

  it('1.1 - Debe registrar un nuevo usuario exitosamente', async () => {
    const response = await request(app)
      .post('/services/auth/register')
      .send(testUser);
    
    // Verificaciones HTTP
    expect(response.status).toBe(201);
    expect(response.body).toHaveProperty('id');
    expect(response.body.email).toBe(testUser.email);
    expect(response.body.Fullname).toBe(testUser.Fullname);

    // Verificación en base de datos
    const dbUser = await pool.query('SELECT * FROM usuarios WHERE email = $1', [testUser.email]);
    expect(dbUser.rows.length).toBe(1);
    
    // Verificar que la contraseña está hasheada
    const passwordMatch = await bcrypt.compare(testUser.password, dbUser.rows[0].contraseña);
    expect(passwordMatch).toBe(true);
  });  

  it('1.2 - Debe iniciar sesión y obtener token', async () => {
    const response = await request(app)
      .post('/services/auth/login')
      .send({
        email: testUser.email,
        password: testUser.password
      });
    
    // Verificaciones HTTP
    expect(response.status).toBe(200);
    expect(response.headers['set-cookie']).toBeDefined();
    
    // Guardar cookie para pruebas siguientes
    authCookie = response.headers['set-cookie'][0];
    
    // Verificar cuerpo de respuesta
    expect(response.body).toHaveProperty('id');
    expect(response.body.email).toBe(testUser.email);
  });  

  it('1.3 - Debe verificar el token correctamente', async () => {
    const response = await request(app)
      .get('/services/auth/verify-token')
      .set('Cookie', authCookie);

    console.log('RESPONSE BODY:', response.body);
    
    // Verificaciones HTTP
    expect(response.status).toBe(200);
    
    // Verificar datos de usuario
    expect(response.body.email).toBe(testUser.email);
    // Aquí usamos el mismo nombre de propiedad que devuelve tu API
    expect(response.body.Fullname).toBe(testUser.Fullname); // o response.body.fullname dependiendo de tu API
  });

  it('1.4 - Debe cerrar sesión correctamente', async () => {
    // 1. Verificar sesión activa
    const verifyBefore = await request(app)
      .get('/services/auth/verify-token')
      .set('Cookie', authCookie);
    expect(verifyBefore.status).toBe(200);
    
    // 2. Hacer logout
    const logoutResponse = await request(app)
      .post('/services/auth/logout');
    
    // 3. Verificar respuesta de logout
    expect(logoutResponse.status).toBe(200);
    expect(logoutResponse.body.message).toBe('Sesión cerrada correctamente');

    const verifyAfter = await request(app)
    .get('/services/auth/verify-token')
    .set('Cookie', authCookie); // Intenta con el token antiguo
    
    expect(verifyAfter.status).toBe(200); 

  });

  describe('Casos alternativos', () => {
    it('1.5 - Debe fallar al registrar con email duplicado', async () => {
      const response = await request(app)
        .post('/services/auth/register')
        .send(testUser);
      
      expect(response.status).toBe(409);
      expect(response.body.error).toBe('El correo ya está registrado');
    });

    it('1.6 - Debe fallar al iniciar sesión con credenciales inválidas', async () => {
      const response = await request(app)
        .post('/services/auth/login')
        .send({
          email: testUser.email,
          password: "contraseña-incorrecta"
        });
      
      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Contraseña incorrecta');
    });
  });

});