// controllers/materialesController.js
const pool = require('../config/db');

const getMateriales = async (req, res) => {
    try {
        const query = `
            SELECT 
                id,
                codigo,
                material
            FROM 
                materiales
            ORDER BY 
                codigo;
        `;
        
        const result = await pool.query(query);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'No se encontraron materiales' });
        }

        res.json(result.rows);
    } catch (error) {
        console.error('Error al obtener materiales:', error);
        res.status(500).json({ message: 'Error interno del servidor' });
    }
};

const getMaterialById = async (req, res) => {
    const { id } = req.params;

    try {
        const query = `
            SELECT 
                id,
                codigo,
                material
            FROM 
                materiales
            WHERE 
                id = $1;
        `;

        const result = await pool.query(query, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Material no encontrado' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error al obtener material por ID:', error);
        res.status(500).json({ message: 'Error interno del servidor' });
    }
};

const deleteMaterial = async (req, res) => {
  try {
    const { id } = req.params;

    // 1. Validar ID
    if (isNaN(id) || !Number.isInteger(Number(id))) {
      return res.status(400).json({
        message: 'El ID del material debe ser un número entero válido.',
      });
    }

    // 2. Verificar si el material existe
    const materialExiste = await pool.query(
      'SELECT id FROM materiales WHERE id = $1',
      [id]
    );

    if (materialExiste.rowCount === 0) {
      return res.status(404).json({
        message: `No se encontró un material con el ID ${id}.`,
      });
    }

    // 3. Verificar si está asociado a proyectos
    const proyectosAsociados = await pool.query(
      'SELECT COUNT(*) AS total FROM proyecto_material WHERE id_material = $1',
      [id]
    );

    if (Number(proyectosAsociados.rows[0].total) > 0) {
      return res.status(400).json({
        message:
          'No se puede eliminar este material porque está asociado a uno o más proyectos.',
      });
    }

    // 4. Verificar movimientos en bodega_materiales
    const movimientos = await pool.query(
      `
      SELECT 
        COUNT(*) AS total,
        SUM(CASE WHEN tipo = 'Entrada' THEN 1 ELSE 0 END) AS entradas
      FROM bodega_materiales
      WHERE material_id = $1
      `,
      [id]
    );

    const { total, entradas } = movimientos.rows[0];

    // Permitir eliminar solo si tiene 1 movimiento y es Entrada
    if (Number(total) > 1 || Number(entradas) === 0) {
      return res.status(400).json({
        message:
          'No se puede eliminar este material porque tiene movimientos adicionales en bodega.',
      });
    }

    // 5. Eliminar registros de bodega y el material
    await pool.query('DELETE FROM bodega_materiales WHERE material_id = $1', [id]);
    await pool.query('DELETE FROM materiales WHERE id = $1', [id]);

    res.status(200).json({
      message: 'Material eliminado correctamente.',
    });

  } catch (error) {
    console.error('Error en deleteMaterial:', error);
    res.status(500).json({
      message:
        'Error del servidor al eliminar el material. Intenta nuevamente.',
    });
  }
};

const createMateriales = async (req, res) => {
    const { materiales } = req.body;

    // Validate request body
    if (!Array.isArray(materiales) || materiales.length === 0) {
        return res.status(400).json({ 
            message: 'Se debe proporcionar un arreglo de materiales no vacío' 
        });
    }

    // Validate each material object
    for (const material of materiales) {
        if (!material.codigo || !material.material || 
            typeof material.codigo !== 'string' || 
            typeof material.material !== 'string') {
            return res.status(400).json({ 
                message: 'Cada material debe tener código y nombre válidos' 
            });
        }
    }

    try {
        // Start a transaction since we're doing multiple inserts
        await pool.query('BEGIN');

        // Check for duplicate códigos
        const codigos = materiales.map(m => m.codigo);
        const checkDuplicatesQuery = `
            SELECT codigo 
            FROM materiales 
            WHERE codigo = ANY($1)
        `;
        const duplicateCheck = await pool.query(checkDuplicatesQuery, [codigos]);

        if (duplicateCheck.rows.length > 0) {
            await pool.query('ROLLBACK');
            return res.status(400).json({
                message: 'Los siguientes códigos ya existen: ' + 
                    duplicateCheck.rows.map(row => row.codigo).join(', ')
            });
        }

        // Prepare the insert query for multiple rows
        const insertQuery = `
            INSERT INTO materiales (codigo, material)
            VALUES ${materiales.map((_, index) => `($${index * 2 + 1}, $${index * 2 + 2})`).join(', ')}
            RETURNING id, codigo, material;
        `;

        // Flatten the materiales array into a single array of values
        const values = materiales.flatMap(m => [m.codigo, m.material]);

        // Execute the insert
        const result = await pool.query(insertQuery, values);

        // Commit the transaction
        await pool.query('COMMIT');

        res.status(201).json({
            message: 'Materiales creados correctamente',
            materiales: result.rows
        });

    } catch (error) {
        await pool.query('ROLLBACK');
        console.error('Error al crear materiales:', error);
        res.status(500).json({ message: 'Error interno del servidor' });
    }
};

const getTotalCantidad = async (req, res) => {
    try {
        const query = `
            SELECT 
                COALESCE(SUM(cantidad), 0) as total_cantidad
            FROM 
                bodega_materiales;
        `;
        
        const result = await pool.query(query);
        
        // Extraer solo el entero de la suma
        const totalCantidad = parseInt(result.rows[0].total_cantidad);

        res.json(totalCantidad);
    } catch (error) {
        console.error('Error al calcular suma de cantidades:', error);
        res.status(500).json({ message: 'Error interno del servidor' });
    }
};

const getAlertasMateriales = async (req, res) => {
    try {
        const query = `
            SELECT 
                m.id,
                m.codigo,
                m.material,
                COALESCE(SUM(bm.cantidad), 0) AS cantidad_actual,
                COALESCE(SUM(pm.ofertada), 0) AS cantidad_necesaria
            FROM 
                materiales m
            LEFT JOIN 
                bodega_materiales bm ON bm.material_id = m.id
            LEFT JOIN 
                proyecto_material pm ON pm.id_material = m.id
            GROUP BY 
                m.id, m.codigo, m.material
            HAVING 
                COALESCE(SUM(bm.cantidad), 0) < COALESCE(SUM(pm.ofertada), 0)
            ORDER BY 
                m.codigo;
        `;

        const result = await pool.query(query);

        if (result.rows.length === 0) {
            return res.status(200).json({ message: 'No hay materiales con bajo stock' });
        }

        res.json(result.rows);
    } catch (error) {
        console.error('Error al obtener alertas de materiales:', error);
        res.status(500).json({ message: 'Error interno del servidor' });
    }
};


module.exports = {
    getMateriales,
    getMaterialById,
    deleteMaterial,
    createMateriales,
    getTotalCantidad,
    getAlertasMateriales
};
